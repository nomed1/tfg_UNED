.. Introduction chapter frontpage

Introduction
============

This is an introductory chapter to Cuckoo Sandbox.
It explains some basic malware analysis concepts, what's Cuckoo and how it can fit
in malware analysis.

.. toctree::

    sandboxing
    what

