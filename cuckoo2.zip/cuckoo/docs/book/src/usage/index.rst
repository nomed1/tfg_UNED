.. Usage chapter frontpage

Usage
=====

This chapter explains how to use Cuckoo.

.. toctree::

    start
    submit
    web
    api
    dist
    packages
    results
    clean
    utilities
