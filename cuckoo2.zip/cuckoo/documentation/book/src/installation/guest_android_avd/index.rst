======================================
Preparing the Guest (Android Emulator)
======================================

Now it's time to create the Android Emulator and to configure it properly.

    .. warning:: Only one emulator machine is supported!
        Due to the networking configuration,
        we are currently only able to support one machine at a time. This issue will be dealt with in the future.

.. toctree::

	architecture
	host
	requirements
	
	

