
.. _index:

================
CuckooDroid Book
================
Contributed By Check Point Software Technologies LTD.

CuckooDroid is an extension of Cuckoo Sandbox the *Open Source* software for automating analysis of suspicious files.
CuckooDroid brigs to cuckoo the capabilities of execution and analysis of android application.

This guide will explain how to configure the android guest machines and the cuckoo host to support android.


Contents
========

.. toctree::

    introduction/index
    installation/index