# Copyright (C) Check Point Software Technologies LTD.
# This file is part of Cuckoo Sandbox - http://www.cuckoosandbox.org
# See the file 'docs/LICENSE' for copying permission.

from lib.cuckoo.common.abstracts import Signature

class AndroidGooglePlayDiff(Signature):
    name = "android_google_play_diff"
    description = "Application Permissions On Google Play Differ (Osint)"
    severity = 3
    categories = ["android"]
    authors = ["idanr1986"]
    minimum = "0.5"

    def run(self):

        try:
            apk_permission_list = []
            for perm in self.results["apkinfo"]["manifest"]["permissions"]:
                apk_permission_list.append(perm["name"])

            diff = list(set(self.results["googleplay"]["permissions"]) - set(apk_permission_list))
            if(len(diff)> 0):
                return True
            else:
                return False
        except:
            return False
